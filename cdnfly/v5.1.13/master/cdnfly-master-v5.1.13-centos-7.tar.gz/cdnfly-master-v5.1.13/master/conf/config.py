# -*- coding: utf-8 -*-

AES_KEY='69294a1afed3f1f4' #安装时生成一个随机的

MYSQL_IP="localhost"
MYSQL_PORT=3306
MYSQL_USER='root'
MYSQL_PASS='@cdnflypass'
MYSQL_DB='cdn'

LOG_IP="192.168.0.30"
LOG_PORT=9200
LOG_USER="elastic"
LOG_PWD="ES_PWD"

VERSION_NAME="v5.1.13"
VERSION_NUM=50113
CODEPAY_GATEWAY="https://api.xiuxiu888.com/creat_order/"

FORCE_SSL=False
INDEX_PATH="/console/index.html"

